package christmasRaces.core.interfaces;

public interface Engine extends Runnable {
}
