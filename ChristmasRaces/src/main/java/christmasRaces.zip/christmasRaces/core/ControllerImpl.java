package christmasRaces.core;

import christmasRaces.common.ExceptionMessages;
import christmasRaces.common.OutputMessages;
import christmasRaces.core.interfaces.Controller;
import christmasRaces.entities.cars.Car;
import christmasRaces.entities.cars.MuscleCar;
import christmasRaces.entities.cars.SportsCar;
import christmasRaces.entities.drivers.Driver;
import christmasRaces.entities.drivers.DriverImpl;
import christmasRaces.entities.races.Race;
import christmasRaces.entities.races.RaceImpl;
import christmasRaces.repositories.CarRepository;
import christmasRaces.repositories.DriverRepository;
import christmasRaces.repositories.RaceRepository;

import java.util.*;

import static java.util.Map.Entry.comparingByKey;
import static java.util.stream.Collectors.toMap;

public class ControllerImpl implements Controller {
    private DriverRepository driverRepository;
    private CarRepository carRepository;
    private RaceRepository raceRepository;

    public ControllerImpl(DriverRepository driverRepository, CarRepository carRepository, RaceRepository raceRepository) {
        this.driverRepository = driverRepository;
        this.carRepository = carRepository;
        this.raceRepository = raceRepository;
    }

    @Override
    public String createDriver(String driver) {
        Driver driver1 = new DriverImpl(driver);
        if (driverRepository.getAll().contains(driver1)) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.DRIVER_EXISTS,driver));
        }
        driverRepository.add(driver1);
        return String.format(OutputMessages.DRIVER_CREATED,driver);
    }

    @Override
    public String createCar(String type, String model, int horsePower) {
        Car car = null;
        String typeCar = "";
        switch (type) {
            case "Muscle":
                car = new MuscleCar(model,horsePower);
                typeCar = "MuscleCar";
                break;
            case "Sports":
                car = new SportsCar(model,horsePower);
                typeCar = "SportsCar";
                break;
        }
        if (carRepository.getAll().contains(car)) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.CAR_EXISTS,model));
        }
        carRepository.add(car);
        return String.format(OutputMessages.CAR_CREATED,typeCar,model);
    }

    @Override
    public String addCarToDriver(String driverName, String carModel) {
        Driver driver = driverRepository.getByName(driverName);
        Car car = carRepository.getByName(carModel);
        if (driver == null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.DRIVER_NOT_FOUND,driverName));
        }
        if (car == null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.CAR_NOT_FOUND,carModel));
        }
        driver.addCar(car);
        return String.format(OutputMessages.CAR_ADDED,driverName,carModel);
    }

    @Override
    public String addDriverToRace(String raceName, String driverName) {
        Race race  = raceRepository.getByName(raceName);
        Driver driver = driverRepository.getByName(driverName);
        if (driver == null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.DRIVER_NOT_FOUND,driverName));
        }
        if (race == null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_NOT_FOUND,raceName));
        }
        race.addDriver(driver);
        return String.format(OutputMessages.DRIVER_ADDED,driverName,raceName);
    }

    @Override
    public String startRace(String raceName) {
        Race race = raceRepository.getByName(raceName);
        if (race == null) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_NOT_FOUND,raceName));
        }
        Map<Double,Driver> driverMap = new TreeMap<>();
        for (Driver driver : this.driverRepository.getAll()) {
            double v = driver.getCar().calculateRacePoints(race.getLaps());
            driverMap.put(v,driver);
        }
        if (driverMap.size() < 3) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_INVALID,raceName,3));
        }
        driverMap.entrySet()
                .stream()
                .sorted(Collections.reverseOrder(comparingByKey()))
                .collect(toMap(Map.Entry::getKey,Map.Entry::getValue,(e1,e2)->e2,LinkedHashMap::new));
        int count = 3;
        StringBuilder sb = new StringBuilder();

        for (Map.Entry<Double, Driver> doubleDriverEntry : driverMap.entrySet()) {
            Driver name = doubleDriverEntry.getValue();
            if (count == 3) {
                sb.append("Driver ").append(name.getName()).append(" wins ").append(raceName).append(" race.").append(System.lineSeparator());
                this.driverRepository.getByName(name.getName()).winRace();
            } else if (count == 2) {
                sb.append("Driver ").append(name.getName()).append(" is second in ").append(raceName).append(" race.").append(System.lineSeparator());
            } else if (count == 1) {
                sb.append("Driver ").append(name.getName()).append(" is third in ").append(raceName).append(" race.").append(System.lineSeparator());
                break;
            }
            count--;
        }
        this.raceRepository.remove(race);

        return sb.toString().trim();
    }

    @Override
    public String createRace(String name, int laps) {
        Race race = new RaceImpl(name,laps);
        if (raceRepository.getAll().contains(race)) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_EXISTS,name));
        }
        raceRepository.add(race);
        return String.format(OutputMessages.RACE_CREATED,name);
    }
}
